﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Inventario_Gallardo
{
    class conections
    {
        public static MySqlConnection conection()
        {
            MySqlConnectionStringBuilder db = new MySqlConnectionStringBuilder();
            db.Server = "localhost";
            db.UserID = "root";
            db.Password = "";
            db.Database = "gallardo";
            MySqlConnection con = new MySqlConnection(db.ToString());
            return con;

        }

        public static int login(string name)
        {
            MySqlConnection con = conections.conection();
            MySqlCommand com = new MySqlCommand(string.Format("call username_exists('{0}');", name), con);
            MySqlDataReader reader;
            try
            {
                con.Open();
            }
            catch {
                return -1;
            }
            reader = com.ExecuteReader();
            reader.Read();
            int result = reader.GetInt16(0);
            return result;
        }
        public static int insertArticle(string name, int quantity, int cost, int sell, int min)
        {
            MySqlConnection con = conections.conection();
            MySqlCommand com = new MySqlCommand(string.Format("call article_insert('{0}',{1},{2},{3},{4});", name, quantity, cost, sell, min), con);
            try
            {
                con.Open();
            }
            catch
            {
                return -1;
            }
            int i = com.ExecuteNonQuery();
            con.Close();
            return 1;
        }
        public static int updateArticle(string id,string name, int quantity, int cost, int sell, int min)
        {
            MySqlConnection con = conections.conection();
            MySqlCommand com = new MySqlCommand(string.Format("call article_edit({5},'{0}',{1},{2},{3},{4});", name, quantity, cost, sell, min,id), con);
            try
            {
                con.Open();
            }
            catch
            {
                return -1;
            }
            int i = com.ExecuteNonQuery();
            con.Close();
            return 1;
        }

        public static int deleteArticle(string id)
        {
            MySqlConnection con = conections.conection();
            MySqlCommand com = new MySqlCommand(string.Format("call article_delete({0});", id), con);
            try
            {
                con.Open();
            }
            catch
            {
                return -1;
            }
            int i = com.ExecuteNonQuery();
            con.Close();
            return 1;
        }

        public static int modifyQuantity(string id, string quantity)
        {
            MySqlConnection con = conections.conection();
            MySqlCommand com = new MySqlCommand(string.Format("call article_add({0},{1});", id, quantity), con);
            try
            {
                con.Open();
            }
            catch
            {
                return -1;
            }
            int i = com.ExecuteNonQuery();
            con.Close();
            return 1;
        }
        public static DataTable get_articles(int isSimple)
        {
            MySqlConnection con = conections.conection();
            MySqlCommand com;
            DataTable dt = new DataTable();
            try
            {
                con.Open();
            }
            catch
            {
                return dt;
            }
            if (isSimple != 1)
            {
                 com = new MySqlCommand(string.Format("call articles_get();"), con);
            }
            else 
            {
                 com = new MySqlCommand(string.Format("call articles_get_simple();"), con);
            }
                MySqlDataAdapter adap = new MySqlDataAdapter(com);
            adap.Fill(dt);
            con.Close();
            return dt;
        }

        public static DataTable get_articles_store()
        {
            MySqlConnection con = conections.conection();

            DataTable dt = new DataTable();
            try
            {
                con.Open();
            }
            catch
            {
                return dt;
            }
            MySqlCommand com = new MySqlCommand(string.Format("call article_get_store();"), con);
            MySqlDataAdapter adap = new MySqlDataAdapter(com);
            adap.Fill(dt);
            con.Close();
            return dt;
        }

    

    }
}
