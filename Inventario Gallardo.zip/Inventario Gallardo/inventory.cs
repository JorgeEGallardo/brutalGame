﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventario_Gallardo
{
    public partial class inventory : Form
    {
        public inventory()
        {
            InitializeComponent();
        }

        private void Txt_username_TextChanged(object sender, EventArgs e)
        {

        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
        }

        private void Inventory_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = conections.get_articles(0);
            dataGridView1.Columns[0].HeaderText = "Nombre";
            dataGridView1.Columns[1].HeaderText = "Cantidad";
            dataGridView1.Columns[2].HeaderText = "Venta";
            dataGridView1.Columns[3].HeaderText = "Costo";
            dataGridView1.Columns[4].HeaderText = "Minimo";
            dataGridView1.Columns[5].HeaderText = "Utilidad";
            dataGridView1.Columns[6].HeaderText = "Exival";

            dataGridView2.DataSource = conections.get_articles_store();
            dataGridView2.Columns[0].HeaderText = "Nombre";
            dataGridView2.Columns[1].HeaderText = "Cantidad";
            dataGridView2.Columns[2].HeaderText = "Venta";
            dataGridView2.Columns[3].HeaderText = "Costo";
            dataGridView2.Columns[4].HeaderText = "Minimo";
            dataGridView2.Columns[5].HeaderText = "Compra minima";
            dataGridView2.Columns[6].HeaderText = "Inversión";
        }
    }
}
