﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventario_Gallardo
{
    public partial class control : Form
    {
        public control()
        {
            InitializeComponent();
        }
        string id = "0";
        private void Control_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = conections.get_articles(1);
            dataGridView1.Columns[0].HeaderText = "Id";
            dataGridView1.Columns[1].HeaderText = "Nombre";
            dataGridView1.Columns[2].HeaderText = "Cantidad";
            dataGridView1.Columns[3].HeaderText = "Venta";
            dataGridView1.Columns[4].HeaderText = "Costo";
            dataGridView1.Columns[5].HeaderText = "Minimo";
            id = dataGridView1.CurrentRow.Cells[0].Value.ToString();
        }

        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            id = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            label2.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            textBox1.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            textbox.Text = textBox1.Text; 
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            try
            {
                textBox1.Text = (double.Parse(textBox1.Text)+1).ToString();
            }
            catch {
                MessageBox.Show("Error intentando modificar la cantidad.");
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                textBox1.Text = (double.Parse(textBox1.Text) - 1).ToString();
            }
            catch
            {
                MessageBox.Show("Error intentando modificar la cantidad.");
            }
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            try
            {
                int resp = conections.modifyQuantity(id, textBox1.Text);
                dataGridView1.DataSource = conections.get_articles(1);
                dataGridView1.Columns[0].HeaderText = "Id";
                dataGridView1.Columns[1].HeaderText = "Nombre";
                dataGridView1.Columns[2].HeaderText = "Cantidad";
                dataGridView1.Columns[3].HeaderText = "Venta";
                dataGridView1.Columns[4].HeaderText = "Costo";
                dataGridView1.Columns[5].HeaderText = "Minimo"; 
                id = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            }
            catch
            {
                MessageBox.Show("Hubó un problema editando el árticulo, revisa los datos por favor. ");
            }
        }
    }
}
