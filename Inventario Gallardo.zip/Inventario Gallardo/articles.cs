﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventario_Gallardo
{
    public partial class articles : Form
    {
        public articles()
        {
            InitializeComponent();
        }
        string id = "1"; 
        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Articles_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = conections.get_articles(1);
            dataGridView1.Columns[0].HeaderText = "Id";
            dataGridView1.Columns[1].HeaderText = "Nombre";
            dataGridView1.Columns[2].HeaderText = "Cantidad";
            dataGridView1.Columns[3].HeaderText = "Venta";
            dataGridView1.Columns[4].HeaderText = "Costo";
            dataGridView1.Columns[5].HeaderText = "Minimo";
            id = dataGridView1.CurrentRow.Cells[0].Value.ToString();
        }

        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            id =  dataGridView1.CurrentRow.Cells[0].Value.ToString();

            textbox.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            textBox1.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            textBox2.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            textBox3.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            textBox4.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            try
            {
                int resp = conections.updateArticle(id,textbox.Text, Int32.Parse(textBox1.Text), Int32.Parse(textBox2.Text), Int32.Parse(textBox3.Text), Int32.Parse(textBox4.Text));
                dataGridView1.DataSource = conections.get_articles(1);
                dataGridView1.Columns[0].HeaderText = "Id";
                dataGridView1.Columns[1].HeaderText = "Nombre";
                dataGridView1.Columns[2].HeaderText = "Cantidad";
                dataGridView1.Columns[3].HeaderText = "Venta";
                dataGridView1.Columns[4].HeaderText = "Costo";
                dataGridView1.Columns[5].HeaderText = "Minimo";
                id = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            }
            catch
            {
                MessageBox.Show("Hubó un problema editando el árticulo, revisa los datos por favor. ");
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                int resp = conections.insertArticle(textbox.Text,Int32.Parse(textBox1.Text), Int32.Parse(textBox2.Text), Int32.Parse(textBox3.Text), Int32.Parse(textBox4.Text));
                dataGridView1.DataSource = conections.get_articles(1);
                dataGridView1.Columns[0].HeaderText = "Id";
                dataGridView1.Columns[1].HeaderText = "Nombre";
                dataGridView1.Columns[2].HeaderText = "Cantidad";
                dataGridView1.Columns[3].HeaderText = "Venta";
                dataGridView1.Columns[4].HeaderText = "Costo";
                dataGridView1.Columns[5].HeaderText = "Minimo";
                id = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            }
            catch
            {
                MessageBox.Show("Hubó un problema creando el árticulo, revisa los datos por favor. ");
            }
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            if (textbox.Text != "")
            {
                DialogResult result = MessageBox.Show("¿Seguro que quieres borrar toda la información de: " + textbox.Text + "?", "Salir", MessageBoxButtons.YesNo);

                if (result == DialogResult.Yes)
                {
                    conections.deleteArticle(id);
                    dataGridView1.DataSource = conections.get_articles(1);
                    dataGridView1.Columns[0].HeaderText = "Id";
                    dataGridView1.Columns[1].HeaderText = "Nombre";
                    dataGridView1.Columns[2].HeaderText = "Cantidad";
                    dataGridView1.Columns[3].HeaderText = "Venta";
                    dataGridView1.Columns[4].HeaderText = "Costo";
                    dataGridView1.Columns[5].HeaderText = "Minimo";
                }
            }
        }
    }
}
